<form action = "store.php" method="post">
    <input type="text" name="title"> <br>
    <textarea name="content"></textarea> <br>
    <button type="submit">Submit</button>


</form>