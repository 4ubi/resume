<form action = "<?php echo e(url('store')); ?>" method="post">
    <input type="text" name="title"> <br>
    <textarea name="content"></textarea> <br>
    <button type="submit">Submit</button>


</form>