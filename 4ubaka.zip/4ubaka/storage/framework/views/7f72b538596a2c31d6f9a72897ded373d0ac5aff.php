<!doctype html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Юный ПХПшник</title>
    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('public/css/style.css')); ?>" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="<?php echo e(asset('public/css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Lobster|Ubuntu+Condensed" rel="stylesheet">
</head>

<body>
    <div class="card-header">
        <h1>Записки юного пхпшника</h1>
    </div>
    <div class="row">
        <div class="col-xl-2">
            <div class="menu" style="text-align: center">
                Меню<br>
                bla bla<br>
                bla bla
            </div>

        </div>
        <div class="col-xl-10">
            Равным образом сложившаяся структура организации играет важную роль в формировании существенных финансовых и административных условий. Задача организации, в особенности же консультация с широким активом требуют от нас анализа форм развития. Задача организации, в особенности же консультация с широким активом играет важную роль в формировании дальнейших направлений развития. Разнообразный и богатый опыт рамки и место обучения кадров представляет собой интересный эксперимент проверки новых предложений.

            Повседневная практика показывает, что новая модель организационной деятельности представляет собой интересный эксперимент проверки дальнейших направлений развития. Значимость этих проблем настолько очевидна, что дальнейшее развитие различных форм деятельности требуют определения и уточнения системы обучения кадров, соответствует насущным потребностям.
        </div>
    </div>


<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
<script src="../../assets/js/vendor/popper.min.js"></script>
<script src="../../dist/js/bootstrap.min.js"></script>
</body>
</html>