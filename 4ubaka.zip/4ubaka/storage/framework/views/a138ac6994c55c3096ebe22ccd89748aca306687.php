<?php ?>

<a href="create"> Переход к загатовке</a>
<a href="mvc/index"> Переход к загатовке</a>